/*
 * Copyright (c) 2000-2007 Apple Inc. All rights reserved.
 */
/*
 * @OSF_COPYRIGHT@
 */

#ifndef	_MACH_I386_RPC_H_
#define	_MACH_I386_RPC_H_

#endif /* _MACH_I386_RPC_H_ */
